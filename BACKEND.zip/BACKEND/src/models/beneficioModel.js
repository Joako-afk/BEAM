// src/models/beneficioModel.js
import { pool } from "../config/db.js";

/**
 * Lista beneficios por ID de categoría.
 * Si tu frontend usa slug de categoría, más abajo te dejo otra función.
 */
export const obtenerBeneficiosPorCategoriaId = async (idCategoria) => {
  const result = await pool.query(
    `
    SELECT
      b.id_beneficio,
      b.nombre,
      b.descripcion,
      b.requisitos,
      b.costo,
      b.edad_minima,
      b.slug,
      b.icon_name,
      b.id_categoria
    FROM beneficio b
    WHERE b.id_categoria = $1
    ORDER BY b.nombre ASC
    `,
    [idCategoria]
  );
  return result.rows;
};

/**
 * Lista beneficios por SLUG de categoría (más cómodo para el frontend).
 * /api/categorias/:slug/beneficios
 */
export const obtenerBeneficiosPorSlugCategoria = async (slugCategoria) => {
  const result = await pool.query(
    `
    SELECT
      b.id_beneficio,
      b.nombre,
      b.descripcion,
      b.requisitos,
      b.costo,
      b.edad_minima,
      b.slug,
      b.icon_name,
      b.id_categoria
    FROM beneficio b
    JOIN categoria c
      ON b.id_categoria = c.id_categoria
    WHERE c.slug = $1
    ORDER BY b.nombre ASC
    `,
    [slugCategoria]
  );
  return result.rows;
};

/**
 * Beneficio individual + bloques de INFORMACION
 * /api/beneficios/:slug
 */
export const obtenerBeneficioPorSlug = async (slug) => {
  // 1) Obtener el beneficio principal
  const result = await pool.query(
    `
    SELECT
      b.id_beneficio,
      b.nombre,
      b.descripcion,
      b.requisitos,
      b.costo,
      b.edad_minima,
      b.slug,
      b.icon_name,
      b.id_categoria
    FROM beneficio b
    WHERE b.slug = $1
    LIMIT 1
    `,
    [slug]
  );

  const beneficio = result.rows[0];
  if (!beneficio) return null;

  // 2) Traer los bloques de INFORMACION asociados
  const infoResult = await pool.query(
    `
    SELECT
      i.id_info,
      i.bloque,
      i.nombre,
      i.contenido
    FROM informacion i
    JOIN informacion_beneficio ib
      ON ib.id_info = i.id_info   -- 👈 cambio importante
    WHERE ib.id_beneficio = $1
    ORDER BY i.bloque ASC, i.id_info ASC
    `,
    [beneficio.id_beneficio]
  );

  beneficio.info_bloques = infoResult.rows;
  return beneficio;
};
