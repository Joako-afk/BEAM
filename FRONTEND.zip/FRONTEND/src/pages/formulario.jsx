// src/pages/formulario.jsx
export default function Formulario() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Formulario</h1>
      <p className="text-gray-700">Aquí puedes crear nuevas solicitudes.</p>
    </div>
  );
}
